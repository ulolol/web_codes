<link rel="shortcut icon" href="data:image/x-icon;,">
<?php 
  echo date("Y-m-d h:i:sa");
  header("Refresh:1");
?>
